const prices = document.querySelectorAll(".price"); chrome.runtime.sendMessage({count: prices.length});
