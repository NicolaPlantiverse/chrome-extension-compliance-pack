document.body.dataset.ready = localStorage.getItem("seen") || "no";
