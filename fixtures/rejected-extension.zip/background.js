chrome.runtime.onInstalled.addListener(() => fetch("http://api.price-helper.example/install"));
